"""
modules/jd_parser.py

JD Intelligence Engine – parse a job description to extract:
  - must_have skills
  - nice_to_have skills
  - min_experience (years)
  - level (junior / mid / senior / lead)
  - position_title
"""
from __future__ import annotations

import instructor
from groq import Groq
from pydantic import BaseModel, Field

# ==========================================
# KHUÔN ĐÚC DỮ LIỆU JD (PYDANTIC)
# Giữ nguyên cấu trúc Class của bạn để tương thích với app.py
# ==========================================
class JDSummary(BaseModel):
    """Structured metadata extracted from a Job Description using LLM."""
    position_title: str = Field(default="", description="Tên vị trí công việc (VD: Backend Developer)")
    level: str = Field(default="", description="Cấp bậc (Intern, Fresher, Junior, Mid, Senior, Lead). Để trống nếu không rõ.")
    min_experience: int = Field(default=0, description="Số năm kinh nghiệm tối thiểu yêu cầu. (VD: 18 tháng -> 1, 2 năm -> 2). Nếu không yêu cầu rõ, trả về 0.")
    must_have: list[str] = Field(default_factory=list, description="Kỹ năng/Công nghệ BẮT BUỘC. Trích xuất đúng từ khóa, không bịa.")
    nice_to_have: list[str] = Field(default_factory=list, description="Kỹ năng/Công nghệ ƯU TIÊN/LỢI THẾ. Trích xuất đúng từ khóa, không bịa.")
    all_skills: list[str] = Field(default_factory=list)


# ==========================================
# PUBLIC API
# ==========================================
def parse_jd(jd_text: str, api_key: str = "") -> JDSummary:
    """
    Parse a job description and return a JDSummary using LLM extraction.
    """
    # Nếu text rỗng, trả về cấu trúc rỗng
    if not jd_text or not jd_text.strip():
        return JDSummary()
        
    # Nếu không truyền API key, trả về cấu trúc mặc định để giao diện không lỗi
    if not api_key:
        # Tạm thời lấy title từ dòng đầu tiên nếu không có AI
        title = jd_text.split("\n")[0][:80] if jd_text else ""
        return JDSummary(position_title=title)

    try:
        # Bọc Groq client bằng Instructor
        client = instructor.from_groq(Groq(api_key=api_key), mode=instructor.Mode.JSON)
        
        prompt = f"""
        Bạn là một Senior IT Recruiter. Hãy đọc bản Mô tả công việc (JD) dưới đây.
        Nhiệm vụ: Trích xuất các tham số theo đúng định dạng JSON yêu cầu.
        
        QUY TẮC:
        1. Kỹ năng: Phải lấy ĐÚNG từ khóa viết trong JD. KHÔNG ĐƯỢC tự suy luận hay bịa thêm kỹ năng.
        2. Nếu JD viết bằng đoạn văn, hãy nhặt ra các Danh từ chỉ Công nghệ/Nghiệp vụ.
        
        [NỘI DUNG JD]:
        {jd_text}
        """
        
        # Ép LLM nhả JSON chuẩn xác theo JDSummary
        summary = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            response_model=JDSummary,
            messages=[
                {"role": "user", "content": prompt}
            ],
            temperature=0.0,
            max_retries=2
        )
        
        # Tự động gộp mảng all_skills để tiện cho việc highlight trên UI
        summary.all_skills = list(set(summary.must_have + summary.nice_to_have))
        
        return summary
        
    except Exception as e:
        import streamlit as st
        st.error(f"Lỗi AI phân tích JD: {e}")
        return JDSummary()